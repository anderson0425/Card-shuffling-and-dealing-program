//5
vector<int> v1, v2;
  
    // Reserve space in v2
    v2.reserve(N);