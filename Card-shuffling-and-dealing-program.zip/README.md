# Card-shuffling-and-dealing-program
- 老師當初給的只有header file和friver program，其他都是自己加的
- header file成員函式及字串裡面的參數是空的，也是自己加的


1. ex10_11.cpp是driver program
2. Card.cpp 、 Card.h、test_Card
    1. test_Card是用來測試Card object生成及功能是否正常
    2. 經由test_Card測試，目前Card object有照預想中生成了。
3. Hand.cpp、Hand.h
4. DeckOfCards.cpp、DeckOfCards.h